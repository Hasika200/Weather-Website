document.getElementById('form').addEventListener('submit', async function (e) {
  e.preventDefault();
  const location = document.getElementById('search').value.trim();

  if (location) {
      try {
          const data = await getWeatherData(location);

          if (data) {
              displayWeather(data);
          } else {
              alert('City not found. Please try again.');
          }
      } catch (error) {
          console.error('Error fetching data:', error.message);
      }
  }
});

async function getWeatherData(location) {
  const apiKey = '3c730397090ddf4cd1ad44fe11cd28de'; // Replace with your OpenWeatherMap API key
  const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}`;

  try {
      const response = await fetch(apiUrl);

      if (!response.ok) {
          throw new Error('City not found');
      }

      return await response.json();
  } catch (error) {
      throw new Error('Error fetching weather data');
  }
}

function displayWeather(data) {
  const { name, sys, main, weather, wind } = data;
  const mainContainer = document.getElementById('main');
  mainContainer.innerHTML = '';

  const temperature = Math.round(main.temp - 273.15); // Convert temperature to Celsius
  const description = weather[0].description;

  const weatherHTML = `
      <div class="weather">
          <h2>${name}, ${sys.country}</h2>
          <p>${temperature}°C, ${description}</p>
          <div class="more-info">
              <p><span>Humidity:</span> ${main.humidity}%</p>
              <p><span>Wind Speed:</span> ${wind.speed} m/s</p>
          </div>
      </div>
  `;

  mainContainer.innerHTML = weatherHTML;
}

